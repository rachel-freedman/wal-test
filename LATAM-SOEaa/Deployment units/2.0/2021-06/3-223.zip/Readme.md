#PKG 3 Release Notes

WorkItem:
#223
##This PKG contain the following files:
```
\3\Package.zip
```

##Changeset c37b10d1e54c6278bab1bd6c80afbcb2ea9638e3 Comment
rachel-freedman
