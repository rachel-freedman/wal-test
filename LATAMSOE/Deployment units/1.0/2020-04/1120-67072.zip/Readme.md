#PKG 1120 Release Notes

WorkItem:
#67072
##This PKG contain the following files:
```
$/YuvalTest/Sequence/Pre Scripts/test.sql
```

##Changeset 16997 Comment
Added file test.sql
