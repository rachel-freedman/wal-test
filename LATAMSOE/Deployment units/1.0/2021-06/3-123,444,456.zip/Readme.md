#PKG 3 Release Notes

WorkItems:
#123
#456
#444
##This PKG contain the following files:
```
\Pre Scripts\test.sql
```

##Changeset 7167c6b89e695814dbb132e9935c497668b20264 Comment
rachel-freedman
