#PKG 3 Release Notes

WorkItem:
#221
##This PKG contain the following files:
```
\Stored Procedures\CDEVCICD1.dbo.USPEXAMPLE.sql
```

##Changeset 0ba3bafcd916f38603928975e8510e7314a85ca3 Comment
rachel-freedman
