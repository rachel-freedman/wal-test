#PKG 3 Release Notes

WorkItems:
#555
#4433
##This PKG contain the following files:
```
\StoredProcedures\spWFADummy.sql
\Workflows\Racheli Sandbox.zip
\StoredProcedures\spwfa_copycustomdataexmaple.sql
```

##Changeset d20acbe8dcbf3a91921f0013bd2e30d5a8a372a1 Comment
rachel-freedman
##Changeset 649f67eef0f9367b9d2ce302a16d3319a8b612fd Comment
rachel-freedman
##Changeset 8646a1b25221dd72a42d58c241a403fc50c5f3e3 Comment
rachel-freedman
##Changeset 1371a837c8f17d829288b2e9daff1f3adbf750aa Comment
rachelf
##Changeset e6e250736165019c16d995892bd7a0c3f86c327f Comment
rachelf
##Changeset 4829ee8addf8d5847f693a04ef4ca75aaf862cec Comment
rachelf
##Changeset f50f2ca1a2da3bd8394ac24c983fddff18a4c372 Comment
rachelf
##Changeset c7ef787806666a5d3ba9c889c118276e97205472 Comment
rachel-freedman
##Changeset 2825c60d5249cf8c6f575997c55e7abbf833f8eb Comment
rachel-freedman
