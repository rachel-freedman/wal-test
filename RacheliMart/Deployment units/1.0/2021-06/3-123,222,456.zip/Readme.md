#PKG 3 Release Notes

WorkItems:
#123
#456
#222
##This PKG contain the following files:
```
\Shared Resources\a.txt
\Stored Procedures\CDEVCICD1.dbo.USPEXAMPLE.sql
\archive wf\Documentation.html
\Pre Scripts\test.sql
```

##Changeset deb2f1d0ee2a50629950399f9d23ddeddbbf3dfd Comment
rachel-freedman
##Changeset b2771048517cc2b3bfb21df96381bab3a21e2984 Comment
rachel-freedman
##Changeset 37059d20ced134c9c7522873917c27b142c53b25 Comment
rachel-freedman
##Changeset 13ee387473221e934ec1dbec5e577398259b23a4 Comment
rachel-freedman
