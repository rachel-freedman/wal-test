#PKG 2 Release Notes

WorkItem:
#75408
##This PKG contain the following files:
```
$/YuvalTest/Sequence/Workflows/my first project/my first project/WorkflowPackage.zip
$/YuvalTest/Sequence/Workflows/my first project/my first project/Documentation.html
$/YuvalTest/Sequence/Stored Procedures/CDEVCICD1.dbo.USPEXAMPLE.sql
```

##Changeset 19791 Comment
This changeset was created by Yuval Arav.
