#PKG 1121 Release Notes

WorkItem:
#67075
##This PKG contain the following files:
```
$/YuvalTest/Sequence/Shared Resources/a.txt
```

##Changeset 17001 Comment
Added file a.txt
