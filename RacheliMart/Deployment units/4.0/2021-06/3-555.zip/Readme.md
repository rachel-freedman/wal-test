#PKG 3 Release Notes

WorkItem:
#555
##This PKG contain the following files:
```
\Stored Procedures\CDEVCICD1.dbo.USPEXAMPLE.sql
```

##Changeset 46ca6137daeb6a9257d49fe2f4346901e71d3339 Comment
rachel-freedman
