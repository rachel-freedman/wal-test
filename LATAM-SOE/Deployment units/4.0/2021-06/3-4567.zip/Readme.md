#PKG 3 Release Notes

WorkItem:
#4567
##This PKG contain the following files:
```
\StoredProcedures\spWFADummy.sql
```

##Changeset bb9266a50676ec8be56369b68c2b90f2cac638cf Comment
rachel-freedman
