#PKG 3 Release Notes

WorkItems:
#222
#111
#333
##This PKG contain the following files:
```
\Workflows\racheli space name.zip
\Views\a.txt
\Stored Procedures\CDEVCICD1.dbo.USPEXAMPLE.sql
\Stored Procedures\CoraSequence.dbo.USPEXAMPLE.sql
```

##Changeset 4f2483964374925b7f0ed184556fadfed2c1b6f4 Comment
rachelf
##Changeset 88434fccd70afa62432d7ab82f53f418039be31f Comment
rachel-freedman
##Changeset 58f8167ab6d76f0d797075bc57d173b06eab156e Comment
rachel-freedman
##Changeset 1a99c030ac0e80745d3b5d1f26c5d9f355bc43cb Comment
rachel-freedman
