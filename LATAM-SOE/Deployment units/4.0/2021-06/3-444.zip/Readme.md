#PKG 3 Release Notes

WorkItem:
#444
##This PKG contain the following files:
```
\Pre Scripts\test.sql
```

##Changeset c90369cad23c51c116e8773c100aabbc6dd70f2f Comment
rachel-freedman
