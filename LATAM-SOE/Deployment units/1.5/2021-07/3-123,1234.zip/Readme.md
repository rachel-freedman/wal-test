#PKG 3 Release Notes

WorkItems:
#123
#1234
##This PKG contain the following files:
```
\Stored Procedures\CTSTOPMRF.dbo.spWFADummy.sql
\Stored Procedures\CTSTOPMRF.dbo.spwfa_copycustomdataexmaple.sql
\RacheliSandbox\Documentation.html
\RacheliSandbox\WorkflowPackage.zip
\racheli space name\Documentation.html
\racheli space name\WorkflowPackage.zip
```

##Changeset 8467dccdcf537ad1d57a80b2a841834910ddb76a Comment
rachelf
##Changeset c532686dccd2e63959fa109ec80a78e8ba8fbee0 Comment
rachelf
##Changeset af90463f6d27a57e73fc12903a058c88126056ab Comment
rachelf
##Changeset e5dd8b135d7b1d14b141938084d84074729e6851 Comment
rachelf
##Changeset 3bb97d5d3cfeb116f3219e3981ab969394b9ae90 Comment
rachelf
##Changeset f5cef63cea1398d7fd97121f86d4ff13aaec78d8 Comment
rachelf
##Changeset bbeb3b621c33386ab457cbcb0980eae481f60a7c Comment
rachelf
##Changeset 24ff45d5432efc9c3f75a3da6a1af8b5502f35d7 Comment
rachelf
##Changeset 3b915be15ee4651dee34c18b43f9057147ed2d64 Comment
rachelf
##Changeset 162f7a5c9aefcab09d344de267bb1799f90ddf7b Comment
rachelf
##Changeset 0fd4adc358b859a2f2332bd82721370b09835e2e Comment
rachelf
##Changeset 8e0f8e2e6478e80c7d21fb82bcd9c19594b328a4 Comment
rachelf
