#PKG 4 Release Notes

WorkItem:
#12345
##This PKG contain the following files:
```
\testProcess\Documentation.html
\testProcess\WorkflowPackage.zip
```

##Changeset 7c5953ca9c6cb932aa9c4b7e725044fb52912251 Comment
rachelf
##Changeset 03077774b3a27972ad9f58b757fc201e9b6af1f9 Comment
rachelf
