#PKG 4 Release Notes

WorkItem:
#1234
##This PKG contain the following files:
```
\testProcess\Documentation.html
\testProcess\WorkflowPackage.zip
\racheli space name\Documentation.html
\racheli space name\WorkflowPackage.zip
```

##Changeset 88ae6978df5e45a9fac3e63dca57d38ce11b03bc Comment
rachelf
##Changeset 4a7e7e672c0810742ea9277e089150022ea8c0d6 Comment
rachelf
##Changeset 3b915be15ee4651dee34c18b43f9057147ed2d64 Comment
rachelf
##Changeset 162f7a5c9aefcab09d344de267bb1799f90ddf7b Comment
rachelf
##Changeset 0fd4adc358b859a2f2332bd82721370b09835e2e Comment
rachelf
##Changeset 8e0f8e2e6478e80c7d21fb82bcd9c19594b328a4 Comment
rachelf
