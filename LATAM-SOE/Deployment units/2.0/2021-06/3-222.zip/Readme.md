#PKG 3 Release Notes

WorkItem:
#222
##This PKG contain the following files:
```
\Views\a.txt
```

##Changeset 88434fccd70afa62432d7ab82f53f418039be31f Comment
rachel-freedman
