#PKG 3 Release Notes

WorkItem:
#221
##This PKG contain the following files:
```
\3\CDEVCICD1.dbo.USPEXAMPLE.sql
```

##Changeset b12dbd84a91602461df114e9a5c488e47fd86f6f Comment
rachel-freedman
