#PKG 3 Release Notes

WorkItem:
#224
##This PKG contain the following files:
```
\StoredProcedures\spWFADummy.sql
```

##Changeset 14e63e78affbc413d9da91b9a346010ab527931d Comment
rachel-freedman
