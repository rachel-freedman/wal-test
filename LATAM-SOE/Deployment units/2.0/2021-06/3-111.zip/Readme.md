#PKG 3 Release Notes

WorkItem:
#111
##This PKG contain the following files:
```
\Stored Procedures\CDEVCICD1.dbo.USPEXAMPLE.sql
```

##Changeset 58f8167ab6d76f0d797075bc57d173b06eab156e Comment
rachel-freedman
