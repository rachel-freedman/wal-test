#PKG 3 Release Notes

WorkItem:
#111
##This PKG contain the following files:
```
\3\CDEVCICD1.dbo.USPEXAMPLE.sql
```

##Changeset e742dd0e7e0baeaad1a46d9a1ab38bedbe2561b3 Comment
rachel-freedman
