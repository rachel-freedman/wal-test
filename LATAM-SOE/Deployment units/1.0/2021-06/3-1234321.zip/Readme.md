#PKG 3 Release Notes

WorkItem:
#1234321
##This PKG contain the following files:
```
\3\spwfa_copycustomdataexmaple.sql
\3\RacheliSandbox.zip
```

##Changeset 7f6b20c5ef128fe53ef745bd6ee627355df6824a Comment
rachelf
##Changeset eca69591b9df8d6c3df4b0840802472845bf8218 Comment
rachelf
