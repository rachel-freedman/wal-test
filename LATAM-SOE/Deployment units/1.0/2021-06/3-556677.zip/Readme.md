#PKG 3 Release Notes

WorkItem:
#556677
##This PKG contain the following files:
```
\StoredProcedures\spwfa_copycustomdataexmaple.sql
\Workflows\RacheliSandbox.zip
```

##Changeset 3845a3adb0c95b8d4fb9f5a23f0627f7a25ef279 Comment
rachelf
##Changeset e3a84d5b115817b6d05553f024b449694bcef4a9 Comment
rachelf
