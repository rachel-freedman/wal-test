#PKG 3 Release Notes

WorkItem:
#4567
##This PKG contain the following files:
```
\3\spWFADummy.sql
```

##Changeset 1e0ca070d62ab627ba316d70938b3ced9ba84677 Comment
rachel-freedman
